Porada: Za pomocą C-x t kopiuje się nazwy zaznaczoych plików do wiersza poleceń.
Porada: Za pomocą C-x p kopiuje się nazwę bieżącej ścieżki do wiersza poleceń.
Porada: Uzupełnianie: M-Tab (lub Esc+Tab). Podwójne wciśnięcie wywołuje listę.
Porada: M-p i M-n udostępnia historię poleceń.
Porada: Cytowanie znaku można uzyskać naciskając Contrl-q i odpowiedni znak.
Porada: Zmęczony poradami? Wyłącz je w menu Opcje|Układ...
Porada: Wybieranie katalogów: dodaj ukośnik na końcu wzorca dopasowania.
Porada: Jeśli w twoim terminalu brak klawiszy funkcyjnych, użyj Esc+numer.
Porada: Witryna Midnight Commandera jest pod adresem http://www.midnight-commander.org/
Porada: Strona domowa Midnight Commandera pod adresem http://www.midnight-commander.org/
Porada: Opis błędów (w języku angielskim) wysyłaj na mc-devel@gnome.org
Porada: Za pomocą klawisza Tab zmienia się bieżący panel.
Porada: VFS: naciśnij Enter na archiwum tar, aby obejrzeć jego zawartość.
Porada: Na stronę podręcznikową też warto zajrzeć.
Porada: Chcesz się poruszać tak jak w lynksie? Ustaw to w menu Konfiguracja...
Porada: Makra % działają nawet w wierszu poleceń.
Porada: M-! pozwala na podgląd wyjścia uruchamianych programów w przeglądarce.
Porada: Tryb wyświetlania listy plików można dostosowywać: zobacz "man mc".
Porada: %D/%T oznacza zazanaczone pliki w drugim panelu.
Porada: Dostęp do zwykłej powłoki przez C-o. Powrót do MC przez ponowne C-o.
Porada: Ustawienie zmiennej CDPATH może ci zaoszczędzić pisania.
Porada: Jeśli chcesz zobaczyć pliki .*, zmień ustawienie w menu Konfiguracja...
Porada: Jeśli chcesz zobaczyć pliki .*~, zmień ustawienie w menu Konfiguracja...
Porada: Uzupełnianie działa wszędzie. Po prostu naciśnij M-Tab.
Porada: Jeśli masz powolny terminal, spróbuj użyć opcji -s.
Porada: Znajdź plik: na znalezionych plikach wykonujemy operacje poprzez Filtruj.
Porada: Chcesz użyć złożonego wyszukiwania? Użyj polecenia Filtr zewnętrzny.
Porada: Jeśli chcesz szybciej zmieniać ścieżkę, użyj M-c (szybka zmiana katalogu).
Porada: Polecenia powłoki działają tylko w lokalnym systemie plików.
Porada: Przywróć skasowany tekst za pomocą C-y.
Porada: Niektóre klawisze nie działają? Patrz menu Opcje|Definiuj klawisze...
Porada: Aby obejrzeć wyjście polecenia w przeglądarce użyj M-!
Porada: F13 (lub Shift-F3) wywołuje przeglądarkę w trybie surowym.
Porada: Możesz określić edytor pod F4 przez zmienną powłoki EDITOR.
Porada: Możesz określić zewnętrzną przeglądarkę przez zmienną powłoki PAGER.
Porada: Możesz wyłączyć żądania potwierdzenia przez menu Opcje|Potwierdzanie...
Porada: Przejdź do listy najczęściej używanych katalogów przez C-\.
Porada: Z anonimowego FTP korzystamy pisząc 'cd /#ftp:machine.edu'
Porada: MC ma wbudowaną obsługę FTP; patrz menu Plik, Połączenie FTP...
Porada: M-t przełącza tryby wyświetlania listy plików.
Porada: Użytkownika FTP określamy przez: 'cd /#ftp:user@machine.edu'
Porada: Pakiety RPM przeglądamy naciskając na nich Enter.
Porada: Aby zazanaczyć katalogi w oknie dialogowym zaznaczania dodaj ukośnik.
Porada: Używanie kopiowania i wklejania za pomocą myszy może wymagać Shifta.
Porada: Klawiszem C-\ dopisz do podręcznej listy często odwiedzane zasoby FTP.
